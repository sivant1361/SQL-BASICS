create
    definer = root@localhost procedure inblood(IN sno int, IN bgrp varchar(10), IN bqty int, IN pid int, IN bid int,
                                               IN did int)
begin 
insert into blood values(sno,bgrp,bqty,pid,bid,did);
end;

