create
    definer = root@localhost procedure inbloodspl(IN sno int, IN bgrp varchar(10), IN bqty int, IN bid int, IN did int)
begin 
insert into blood(sno,bgrp,bqty,bid,did) values(sno,bgrp,bqty,bid,did);
end;

