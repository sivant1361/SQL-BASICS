create
    definer = root@localhost procedure inbloodbank(IN bid int, IN bname varchar(30), IN baddr varchar(30),
                                                   IN bcno bigint)
begin 
insert into bloodbank values(bid,bname,baddr,bcno);
end;

