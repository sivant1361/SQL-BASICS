create
    definer = root@localhost procedure inpatient(IN pid int, IN pname varchar(15), IN pdisease varchar(15))
begin 
insert into patient values(pid,pname,pdisease);
end;

