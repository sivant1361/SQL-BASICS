create
    definer = root@localhost procedure indonor(IN did int, IN dname varchar(15), IN dmedrep varchar(15),
                                               IN daddr varchar(30), IN dcno bigint)
begin 
insert into donor values(did,dname,dmedrep,daddr,dcno);
end;

